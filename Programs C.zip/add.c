#include<stdio.h>

int main()
{

int a,b;
printf("Enter the two numbers");
scanf("%d\n %d", &a,&b);
//int a=3;
//int b=2;
double c=a/b;

printf("The addition is: %d\n", (a+b));
printf("The subtraction is: %d\n", (a-b));
printf("The multiplication is: %d\n", (a*b));
printf("The division is: %f\n", (float)a/b);


return 0;
}

 







